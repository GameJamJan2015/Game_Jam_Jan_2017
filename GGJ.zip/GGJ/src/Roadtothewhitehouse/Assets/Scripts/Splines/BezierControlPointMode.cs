﻿public enum BezierControlPointMode {
	Free,
	Aligned,
	Mirrored
}